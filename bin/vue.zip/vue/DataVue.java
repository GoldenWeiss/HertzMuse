package vue;

public class DataVue {

}
