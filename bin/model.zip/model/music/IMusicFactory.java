package model.music;

import controleur.DataModele;

public interface IMusicFactory
{
	public void update(DataModele data);
}